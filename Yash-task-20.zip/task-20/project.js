
let cart = [];

const cartItems = document.querySelector("#cart-items");
const total = document.querySelector("#total");
const bookingForm = document.querySelector("#booking-form");
const bookingMessage = document.querySelector("#booking-message");
const bookButton = document.querySelector("#book-button");

const PUBLIC_KEY = "YOUR_EMAILJS_PUBLIC_KEY";
const SERVICE_ID = "YOUR_EMAILJS_SERVICE_ID";
const TEMPLATE_ID = "YOUR_EMAILJS_TEMPLATE_ID";

if (window.emailjs && !PUBLIC_KEY.startsWith("YOUR_")) {
    emailjs.init({
        publicKey: PUBLIC_KEY
    });
}

const serviceCards = document.querySelectorAll(".service-card");

serviceCards.forEach(function(card) {
    const addButton = card.querySelector(".add-btn");
    const removeButton = card.querySelector(".remove-btn");

    addButton.addEventListener("click", function() {
        const name = card.dataset.name;
        const price = Number(card.dataset.price);

        cart.push({
            name: name,
            price: price
        });

        updateCart();
    });

    removeButton.addEventListener("click", function() {
        const name = card.dataset.name;
        const index = cart.findIndex(function(item) {
            return item.name === name;
        });

        if (index !== -1) {
            cart.splice(index, 1);
            updateCart();
        } else {
            alert("This service is not in your cart.");
        }
    });
});

function updateCart() {
    cartItems.innerHTML = "";

    let sum = 0;

    if (cart.length === 0) {
        cartItems.innerHTML = '<p class="empty-cart">No items added yet.</p>';
    }

    cart.forEach(function(item, index) {
        const itemDiv = document.createElement("div");
        itemDiv.className = "cart-item";

        const itemName = document.createElement("span");
        itemName.textContent = item.name + " - ₹" + item.price;

        const removeButton = document.createElement("button");
        removeButton.textContent = "Remove";

        removeButton.addEventListener("click", function() {
            cart.splice(index, 1);
            updateCart();
        });

        itemDiv.appendChild(itemName);
        itemDiv.appendChild(removeButton);
        cartItems.appendChild(itemDiv);

        sum += item.price;
    });

    total.textContent = sum;
}

bookingForm.addEventListener("submit", async function(event) {
    event.preventDefault();

    if (cart.length === 0) {
        bookingMessage.style.color = "red";
        bookingMessage.textContent = "Please add items to your cart first.";
        return;
    }

    if (
        !window.emailjs ||
        PUBLIC_KEY.startsWith("YOUR_") ||
        SERVICE_ID.startsWith("YOUR_") ||
        TEMPLATE_ID.startsWith("YOUR_")
    ) {
        bookingMessage.style.color = "red";
        bookingMessage.textContent =
            "Please configure EmailJS before placing your booking.";
        return;
    }

    const name = document.querySelector("#full-name").value.trim();
    const email = document.querySelector("#email").value.trim();
    const phone = document.querySelector("#phone").value.trim();

    const orderDetails = cart.map(function(item) {
        return item.name + " - ₹" + item.price;
    }).join("\n");

    const amount = cart.reduce(function(sum, item) {
        return sum + item.price;
    }, 0);

    const templateParams = {
        customer_name: name,
        customer_email: email,
        customer_phone: phone,
        order_details: orderDetails,
        total_amount: amount
    };

    bookButton.disabled = true;
    bookButton.textContent = "Sending...";
    bookingMessage.style.color = "#555";
    bookingMessage.textContent = "Sending your booking details...";

    try {
        await emailjs.send(SERVICE_ID, TEMPLATE_ID, templateParams);

        bookingMessage.style.color = "green";
        bookingMessage.textContent =
            "Thank you For Booking the Service We will get back to you soon!";

        cart = [];
        updateCart();
        bookingForm.reset();

    } catch (error) {
        bookingMessage.style.color = "red";
        bookingMessage.textContent =
            "Booking email could not be sent. Please try again.";

        console.error("EmailJS error:", error);
    } finally {
        bookButton.disabled = false;
        bookButton.textContent = "Book Now";
    }
});

document.querySelector("#newsletter-form").addEventListener("submit", function(event) {
    event.preventDefault();

    const name = document.querySelector("#newsletter-name").value.trim();

    document.querySelector("#newsletter-message").textContent =
        "Thank you for subscribing, " + name + "!";

    this.reset();
});
